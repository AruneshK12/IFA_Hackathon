package com.ssn.aasha.ui.Floods;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class FloodsViewModel extends ViewModel {
    private MutableLiveData<String> mText;

    public FloodsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Floods fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
