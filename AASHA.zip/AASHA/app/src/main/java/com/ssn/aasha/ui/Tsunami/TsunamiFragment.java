package com.ssn.aasha.ui.Tsunami;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.ssn.aasha.R;
import com.ssn.aasha.ui.Tsunami.TsunamiViewModel;

public class TsunamiFragment extends Fragment {
    private TsunamiViewModel tsunami;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        tsunami=
                ViewModelProviders.of(this).get(TsunamiViewModel.class);
        View root = inflater.inflate(R.layout.fragment_tsunami, container, false);
        //final TextView textView = root.findViewById(R.id.text_tsunami);
        tsunami.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                //textView.setText(s);
            }
        });
        return root;
    }
}
