package com.ssn.aasha.ui.Tsunami;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class TsunamiViewModel extends ViewModel{
        private MutableLiveData<String> mText;

        public TsunamiViewModel() {
            mText = new MutableLiveData<>();
            mText.setValue("This is Tsunami fragment");
        }

        public LiveData<String> getText() {
            return mText;
        }
}
