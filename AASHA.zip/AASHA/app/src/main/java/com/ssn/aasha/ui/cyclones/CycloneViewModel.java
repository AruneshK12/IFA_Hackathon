package com.ssn.aasha.ui.cyclones;


import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class CycloneViewModel extends ViewModel {
    private MutableLiveData<String> mText;

    public CycloneViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Cyclone fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
