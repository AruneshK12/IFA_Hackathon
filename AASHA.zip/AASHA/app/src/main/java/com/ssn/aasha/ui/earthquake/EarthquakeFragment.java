package com.ssn.aasha.ui.earthquake;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.ssn.aasha.MapsActivity1;
import com.ssn.aasha.R;
import com.ssn.aasha.ui.earthquake.EarthquakeViewModel;

public class EarthquakeFragment extends Fragment {
    private EarthquakeViewModel earthquakeViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        earthquakeViewModel =
                ViewModelProviders.of(this).get(EarthquakeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_earthquake, container, false);
        //ImageView image=root.findViewById(R.id.card_view_image);
        //image.setImageResource(R.drawable.testimage);

        earthquakeViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                //cardview.setVisibility(View.VISIBLE);

            }
        });
        return root;
    }


}
