package com.ssn.aasha.ui.earthquake;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class EarthquakeViewModel extends ViewModel {
    private MutableLiveData<String> mText;

    public EarthquakeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Earthquake fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
