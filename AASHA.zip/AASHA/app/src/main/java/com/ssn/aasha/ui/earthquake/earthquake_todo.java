package com.ssn.aasha.ui.earthquake;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.ssn.aasha.R;

public class earthquake_todo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.layout_earthquake_todo);
        setTitle(R.string.emergencykit);
    }

    public void checkProgress(View view)
    {
        TextView textView=findViewById(R.id.textView7);
        ProgressBar progress=(ProgressBar) findViewById(R.id.progressBar);
        CheckBox check1=(CheckBox) findViewById(R.id.checkBox1);
        CheckBox check2=(CheckBox) findViewById(R.id.checkBox2);
        CheckBox check3=(CheckBox) findViewById(R.id.checkBox3);
        CheckBox check4=(CheckBox) findViewById(R.id.checkBox4);
        CheckBox check5=(CheckBox) findViewById(R.id.checkBox5);
        CheckBox check6=(CheckBox) findViewById(R.id.checkBox6);
        CheckBox check7=(CheckBox) findViewById(R.id.checkBox7);
        CheckBox check8=(CheckBox) findViewById(R.id.checkBox8);
        CheckBox check9=(CheckBox) findViewById(R.id.checkBox9);
        CheckBox check10=(CheckBox) findViewById(R.id.checkBox10);
        CheckBox check11=(CheckBox) findViewById(R.id.checkBox11);
        CheckBox check12=(CheckBox) findViewById(R.id.checkBox12);
        textView.setText("BE PREPARED PROCURE ALL THE GIVEN ITEMS");
        progress.setProgress(0);
        if(check1.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(check2.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(check3.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(check4.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(check5.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(check6.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(check7.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(check8.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(check9.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(check10.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(check11.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(check12.isChecked())
        {
            progress.setProgress(progress.getProgress()+9);
        }
        if(progress.getProgress()>=100)
        {
            textView.setText("CONGRATULATIONS YOU ARE WELL PREPARED");
        }
        if(progress.getProgress()>=50 && progress.getProgress()<100)
        {
            textView.setText("KEEP GOING YOU ARE HALFWAY THERE");
        }
    }
}
