package com.ssn.aasha.ui.landslides;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class LandslidesViewModel extends ViewModel {
    private MutableLiveData<String> mText;

    public LandslidesViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Landslides fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}
