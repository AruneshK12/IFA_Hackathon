package com.ssn.aasha.ui.nearngo;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.ssn.aasha.MapsActivity1;
import com.ssn.aasha.R;
import com.ssn.aasha.ui.nearngo.NearngoViewModel;

public class NearngoFragment extends Fragment {
    private NearngoViewModel nearngo;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        nearngo=
                ViewModelProviders.of(this).get(NearngoViewModel.class);
        View root = inflater.inflate(R.layout.fragment_nearngo, container, false);
        //final TextView textView = root.findViewById(R.id.text_nearngo);
        nearngo.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                //textView.setText(s);
            }
        });
        Intent intent = new Intent(getActivity(), MapsActivity1.class);
        startActivity(intent);
        return root;
    }

}
